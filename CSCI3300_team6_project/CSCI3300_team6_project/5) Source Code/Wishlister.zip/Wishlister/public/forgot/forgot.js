window.onload = async (event) => {
	var forgotForm = document.getElementById("forgotForm");
	var passwordInput = document.getElementById("password");
	var confirmPasswordInput = document.getElementById("confirm_password");
	var passwordRequirements = document.getElementById("passwordRequirements");
	var passwordReqListItems = passwordRequirements.querySelectorAll("li");
	var togglePassword = document.getElementById("togglePassword");
    var error = document.getElementById("forgotAlert");
	error.style.display = 'none';
  
	await fetch('/api/rules')
		.then(response => response.json())
		.then(rules => {
			if(rules[0].wrongInfo){
				error.style.display = 'block';
			} else {
				error.style.display = 'none';
			}
		});

	// Function to validate password requirements
	function validatePasswordRequirements() {
	  var password = passwordInput.value;
	  var requirementsMet = {
		length: false,
		uppercase: false,
		lowercase: false,
		number: false,
		specialCharacter: false
	  };
  
	  // Check if password meets all requirements
	  if (password.length >= 8) {
		requirementsMet.length = true;
		passwordReqListItems[0].style.display = "none";
	  } else {
		passwordReqListItems[0].style.display = "block";
	  }
  
	  if (/[A-Z]/.test(password)) {
		requirementsMet.uppercase = true;
		passwordReqListItems[1].style.display = "none";
	  } else {
		passwordReqListItems[1].style.display = "block";
	  }
  
	  if (/[a-z]/.test(password)) {
		requirementsMet.lowercase = true;
		passwordReqListItems[2].style.display = "none";
	  } else {
		passwordReqListItems[2].style.display = "block";
	  }
  
	  if (/\d/.test(password)) {
		requirementsMet.number = true;
		passwordReqListItems[3].style.display = "none";
	  } else {
		passwordReqListItems[3].style.display = "block";
	  }
  
	  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
		requirementsMet.specialCharacter = true;
		passwordReqListItems[4].style.display = "none";
	  } else {
		passwordReqListItems[4].style.display = "block";
	  }
  
	  // Check if all requirements are met
	  if (Object.values(requirementsMet).every(Boolean)) {
		passwordRequirements.style.display = "none";
		return true; // Return true if all requirements are met
	  } else {
		passwordRequirements.style.display = "block";
		return false; // Return false if any requirement is not met
	  }
	}

	//Ensuure password field is hidden
	passwordInput.setAttribute('type', 'password');
	confirmPasswordInput.setAttribute('type', 'password');
	securAns.setAttribute('type', 'password');
  
	// Toggle password visibility logic
	togglePassword.addEventListener("click", function() {
	  var type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
	  passwordInput.setAttribute("type", type);
	});
  
	// Toggle confirm password visibility logic
	toggleConfirmPassword.addEventListener("click", function() {
	  var type = confirmPasswordInput.getAttribute("type") === "password" ? "text" : "password";
	  confirmPasswordInput.setAttribute("type", type);
	});

	// Toggle security question answer visibility logic
	toggleSecurAns.addEventListener("click", function() {
		var type = securAns.getAttribute("type") === "password" ? "text" : "password";
		securAns.setAttribute("type", type);
	  });
  
	// Add event listeners for input and form submission
	passwordInput.addEventListener("input", validatePasswordRequirements);
	confirmPasswordInput.addEventListener("input", function() {
	  validatePasswordRequirements();
	  // Check if password and confirm password match
	  if (passwordInput.value === confirmPasswordInput.value && passwordInput.value !== '' && confirmPasswordInput.value !== '') {
		confirmPasswordInput.setCustomValidity('');
	  } else {
		confirmPasswordInput.setCustomValidity('Passwords do not match');
	  }
	});
  
	forgotForm.addEventListener("submit", function(event) {
	  // Validate password requirements before form submission
	  if (!validatePasswordRequirements() || passwordInput.value !== confirmPasswordInput.value) {
		event.preventDefault(); // Prevent form submission if requirements are not met or passwords don't match
	  }
	});
};