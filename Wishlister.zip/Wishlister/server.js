const express = require('express');
const fs = require('fs');
const mysql = require('mysql');
const fileUpload = require('express-fileupload');
const path = require('path');

const app = express();

const serverCa = [fs.readFileSync(__dirname + "/DigiCertGlobalRootCA.crt.pem", "utf8")];

const db = mysql.createConnection({
    host: 'wishlister.mysql.database.azure.com',
    user: 'wishlister_admin',
    password: 'P@ssword1',
    database: 'wishlister',
    port:3306,
    ssl: {
        rejectUnauthorized: true,
        ca: serverCa
    }
});

db.connect( (err) => {
    if(err) {
        console.log(err);
    } else {
        console.log('MySQL Connected...');
    }
});

app.use(fileUpload());
app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(express.static("./public"));

app.listen(3000, () => {
    console.log("Server started on 3000");
});

var emailTaken = false;
var wrongInfo = false;
var isLoggedIn = false;
var passChange = false;
var userId = '';
var userName = '';
var userProf = '';
var userEmail = '';
var userSecQ = '';
var userSecA = '';
var userLists = '';
var editList = '';
var searchLists = '';
var purchaseList = '';

app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/about/about.html'));
});

app.get('/create', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/create/create.html'));
});

app.get('/edit', (req, res) => {
    editList = req.query.listId;
    res.sendFile(path.join(__dirname, '/public/edit/edit.html'));
});

app.get('/forgot', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/forgot/forgot.html'));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/home/home.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/login/login.html'));
});

app.get('/profile', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/profile/profile.html'));
});

app.get('/purchase', (req, res) => {
    purchaseList = req.query.listId;
    res.sendFile(path.join(__dirname, '/public/purchase/purchase.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/register/register.html'));
});

app.get('/search', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/search/search.html'));
});

app.get('/view', (req, res) => {
    const id = userId;
    db.query('SELECT * FROM userlists WHERE id = ?', [id], (err, results) => {
        if(results.length < 1) {
            userLists = '';
        } else {
            userLists = results;
        }
    });
    res.sendFile(path.join(__dirname, '/public/view/view.html'));
});

app.post('/auth/register', (req, res) => {
    const {username, email, password, confrim_password, securQuest, securAns} = req.body;
    const profPic = 'default.png';

    db.query('SELECT email FROM users WHERE email = ?', [email], (err, results) => {
        if(err) {
            console.log(err);
        }

        if(results.length > 0) {
            emailTaken = true;
            isLoggedIn = false;
            return res.redirect('/register');
        }

        db.query('INSERT INTO users SET ?', {username: username, email: email, password: password, profPic: profPic, securQuest: securQuest, securAns: securAns}, (err, results) => {
            if(err) {
                console.log(err);
            } else {
                db.query('SELECT * FROM users WHERE username = ?', [username], (err, results2) => {
                    if((results2.length < 1) || (password !== results2[0].password)) {
                        wrongInfo = true;
                        res.redirect('/login');
                    } else {
                        userId = results2[0].userId;
                        userName = results2[0].username;
                        userEmail = results2[0].email;
                        userProf = results2[0].profPic;
                        userSecQ = results2[0].securQuest;
                        userSecA = results2[0].securAns;
                        emailTaken = false;
                        isLoggedIn = true;
                        res.redirect('/');
                    }
                });
            }
        });
    });
})

app.post('/auth/login', (req, res) => {
    const {username, password} = req.body;

    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if(err){
            console.log(err);
        }else if((results.length < 1) || (password !== results[0].password)) {
            wrongInfo = true;
            passChange = false;
            res.redirect('/login');
        } else {
            userId = results[0].userId;
            userName = results[0].username;
            userEmail = results[0].email;
            userProf = results[0].profPic;
            userSecQ = results[0].securQuest;
            userSecA = results[0].securAns;
            isLoggedIn = true;
            res.redirect('/');
        }
    });

});

app.get('/auth/logout', (req, res) => {
    userId = '';
    userName = '';
    userEmail = '';
    userProf = '';
    isLoggedIn = false;
    userLists = '';
    userSecQ = '';
    userSecA = '';
    res.redirect('/login');
});

app.post('/updatepic', async (req, res) => {
    const id = userId;
    const profPic = req.files.profPic;
    const location = path.join(__dirname, '/public/profile/profile_pictures/', profPic.name);
    await profPic.mv(location);

    db.query('UPDATE users SET profPic = ? WHERE userId = ?', [profPic.name, id], (err, results) => {
        if(err) {
            console.log(err);
        } else {
            userProf = profPic.name;
            res.redirect('/profile');
        }
    });
})

app.post('/auth/create', (req, res) => {
    const id = userId;
    const listName = req.body.list_name;
    var listItems = JSON.stringify(req.body.item);
    var purchased = JSON.stringify(req.body.purchased);

    db.query('INSERT INTO userlists SET ?', {id: id, listName: listName, listItems: listItems, purchased: purchased}, (err, results) => {
            if(err) {
                console.log(err);
            } else {
                return res.redirect('/view');
            }
    });
});

app.post('/auth/edit', (req, res) => {
    const listId = req.body.listId;
    const listName = req.body.list_name;
    var listItems = JSON.stringify(req.body.item);
    var purchased = JSON.stringify(req.body.purchased);

    db.query('UPDATE userlists SET ? WHERE listId = ?', [{listName: listName, listItems: listItems, purchased: purchased}, listId], (err, results) => {
        if(err) {
            console.log(err);
        } else {
            return res.redirect('/view');
        }
    });
});

app.post('/auth/delete', (req, res) => {
    const listId = req.body.listId;

    db.query('DELETE FROM userlists WHERE listId = ?', [listId], (err, results) => {
        if(err) {
            console.log(err);
        } else {
            return res.redirect('/view');
        }
    });
});

app.post('/auth/search', (req, res) => {
    var search = req.body.searchBar;

    db.query('SELECT * FROM users WHERE username = ? or email = ?', [search, search], (err, results) => {
        if(err) {
            console.log(err);
        } else if(results.length < 1) {
            searchLists = 'userdne';
            return res.redirect('/search');
        } else {
            db.query('SELECT * FROM userlists WHERE id = ?', [results[0].userId], (err, results2) => {
                if(err) {
                    console.log(err);
                } else if(results2.length < 1) {
                    searchLists = 'userdnhl';
                    return res.redirect('/search');
                } else {
                    searchLists = results2;
                    return res.redirect('/search');
                }
            });
        }
    });
});

app.post('/auth/purchase', (req, res) => {
    const listId = req.body.listId;
    const listName = req.body.list_name;
    var listItems = JSON.stringify(req.body.item);
    var purchased = JSON.stringify(req.body.purchased);

    db.query('UPDATE userlists SET ? WHERE listId = ?', [{listName: listName, listItems: listItems, purchased: purchased}, listId], (err, results) => {
        if(err) {
            console.log(err);
        } else {
            searchLists = '';
            return res.redirect('/search');
        }
    });
});

app.post('/auth/forgot', (req, res) => {
    const {email, securQuest, securAns, password, confirm_password} = req.body;

    db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
        if(err){
            console.log(err);
        }else if((results.length < 1) || (securQuest !== results[0].securQuest) || (securAns !== results[0].securAns)) {
            wrongInfo = true;
            passChange = false;
            res.redirect('/forgot');
        } else {
            db.query('UPDATE users SET ? WHERE email = ?', [{password: password}, email], (err, results) => {
                if(err) {
                    console.log(err);
                } else {
                    wrongInfo = false;
                    passChange = true;
                    res.redirect('/login');
                }
            });
        }
    });
});

app.get('/api/rules', (req, res) => {
    const rules = [{
        emailTaken: emailTaken,
        isLoggedIn: isLoggedIn,
        wrongInfo: wrongInfo,
        userId: userId,
        userName: userName,
        userEmail: userEmail,
        userProf: userProf,
        userLists: userLists,
        editList: editList,
        searchLists: searchLists,
        purchaseList: purchaseList,
        passChange: passChange
    }]

    res.json(rules);
});
