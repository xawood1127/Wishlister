window.onload = async (event) => {
    const profPic = document.getElementById('profPic');
    const username = document.getElementById('username');
    const email = document.getElementById('email');

    await fetch('/api/rules')
      .then(response => response.json())
      .then(rules => {
        profPic.src = '/profile/profile_pictures/' + rules[0].userProf;
        username.innerHTML = 'Hello ' + rules[0].userName + '!';
        email.innerHTML = rules[0].userEmail;
    });

    localStorage.setItem('userId', rules[0].userId);
};