window.onload = async (event) => {
    const lists = document.getElementById('lists');

    await fetch('/api/rules')
        .then(response => response.json())
        .then(rules => {

            function isUrl(string) {
                try {
                  const url = new URL(string);
                  return url.protocol === 'http:' || url.protocol === 'https:';
                } catch (err) {
                  return false;
                }
            }
            
            if(rules[0].userLists !== ''){
                var html = '';
                for(var i = 0; i < rules[0].userLists.length; i++){
                    html += '<form method="GET" action="/edit" id="editList"><div class="listNameCont"><input type="hidden" id="listId" name="listId" value="' + i + '"><h4>' + rules[0].userLists[i].listName + '</h4><input type="submit" class="submit" value="Edit List"></input></div><ul>';
                    for(var j = 0; j < JSON.parse(rules[0].userLists[i].listItems).length; j++) {
                        if(isUrl(JSON.parse(rules[0].userLists[i].listItems)[j])){
                            html += '<li id="item"><a href="' + JSON.parse(rules[0].userLists[i].listItems)[j] + '">Item ' + (j+1) + '</a> - ' + JSON.parse(rules[0].userLists[i].itemPrices)[j] + '</li>';
                        } else {
                            html += '<li id="item">' + JSON.parse(rules[0].userLists[i].listItems)[j] + '  - ' + JSON.parse(rules[0].userLists[i].itemPrices)[j] + '</li>';
                        }
                    }
                    html += '</ul></form><hr>';
                }
                lists.innerHTML = html;
            } else {
                lists.innerHTML = '<p>You have no lists available, jump over to the create tab to make one now!</p>';
            }
            
            localStorage.setItem('userId', rules[0].userId);
    });
};