window.onload = (event) => {
    const createTab = document.getElementById('create');
    const createLink = document.getElementById('create2');
    const viewTab = document.getElementById('view');
    const viewLink = document.getElementById('view2');
    const regBtn = document.getElementById('register');
    const logBtn = document.getElementById('login');
    const profBtn = document.getElementById('profile');
    const logoBtn = document.getElementById('logout');
    const purchaseList = document.getElementById('purchaseList');
    const listName = document.getElementById('list_name');

    fetch('/api/rules')
      .then(response => response.json())
      .then(rules => {

        if(!rules[0].isLoggedIn && localStorage.getItem('userId') === ''){
            createTab.style.display = 'none';
            createLink.style.display = 'none';
            viewTab.style.display = 'none';
            viewLink.style.display = 'none';
            regBtn.style.display = 'block';
            logBtn.style.display = 'block';
            profBtn.style.display = 'none';
            logoBtn.style.display = 'none';
        } else {
            createTab.style.display = 'block';
            createLink.style.display = 'block';
            viewTab.style.display = 'block';
            viewLink.style.display = 'block';
            regBtn.style.display = 'none';
            logBtn.style.display = 'none';
            profBtn.style.display = 'block';
            logoBtn.style.display = 'block';
        }

        console.log(rules[0].searchLists);

        if(rules[0].searchLists !== ''){
            const id = rules[0].purchaseList; 
            console.log(id);
            listName.value = rules[0].searchLists[id].listName;
            
            const listId = document.createElement('input');
            listId.type = 'hidden';
            listId.id = 'listId';
            listId.name = 'listId';
            listId.value = rules[0].searchLists[id].listId;
            
            purchaseList.appendChild(listId);

            for(var i = 0; i < JSON.parse(rules[0].searchLists[id].listItems).length; i++) {
                const item_container = document.createElement('div');
                item_container.className = 'item-container';

                const item = document.createElement('input');
                item.type = 'text';
                item.id = 'item';
                item.name = 'item';
                item.placeholder = 'Insert Item Here';
                item.value = JSON.parse(rules[0].searchLists[id].listItems)[i];
                item.required = 'true';
                item.readOnly = 'true';

                const hiddenItem = document.createElement('input');
                hiddenItem.type = 'hidden';
                hiddenItem.id = 'purchased';
                hiddenItem.name = 'purchased';
                hiddenItem.value = JSON.parse(rules[0].searchLists[id].purchased)[i];

                const purchasedBtn = document.createElement('input');
                purchasedBtn.type = 'button';
                purchasedBtn.id = 'purchase';
                purchasedBtn.value = hiddenItem.value === 'true' ? 'Purchased' : 'Not Purchased';

                purchaseList.appendChild(item_container);
                item_container.appendChild(item);
                item_container.appendChild(hiddenItem);
                item_container.appendChild(purchasedBtn);

                purchasedBtn.addEventListener('click', function () {
                    if(this.value === 'Not Purchased') {
                        this.value = 'Purchased';

                        const hiddenItem = this.parentNode.querySelector('input[type="hidden"]');
                        hiddenItem.value = 'true';
                    } else {
                        this.value = 'Not Purchased';

                        const hiddenItem = this.parentNode.querySelector('input[type="hidden"]');
                        hiddenItem.value = 'false';
                    }
                    
                });
            }

        }
    });
}