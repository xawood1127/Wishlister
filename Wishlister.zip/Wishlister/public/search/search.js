window.onload = async (event) => {
    const createTab = document.getElementById('create');
    const createLink = document.getElementById('create2');
    const viewTab = document.getElementById('view');
    const viewLink = document.getElementById('view2');
    const regBtn = document.getElementById('register');
    const logBtn = document.getElementById('login');
    const profBtn = document.getElementById('profile');
    const logoBtn = document.getElementById('logout');
    const lists = document.getElementById('lists');

    await fetch('/api/rules')
      .then(response => response.json())
      .then(rules => {

        if(!rules[0].isLoggedIn && localStorage.getItem('userId') === ''){
            createTab.style.display = 'none';
            createLink.style.display = 'none';
            viewTab.style.display = 'none';
            viewLink.style.display = 'none';
            regBtn.style.display = 'block';
            logBtn.style.display = 'block';
            profBtn.style.display = 'none';
            logoBtn.style.display = 'none';
        } else {
            createTab.style.display = 'block';
            createLink.style.display = 'block';
            viewTab.style.display = 'block';
            viewLink.style.display = 'block';
            regBtn.style.display = 'none';
            logBtn.style.display = 'none';
            profBtn.style.display = 'block';
            logoBtn.style.display = 'block';
        }

        function isUrl(string) {
            try {
              const url = new URL(string);
              return url.protocol === 'http:' || url.protocol === 'https:';
            } catch (err) {
              return false;
            }
        }
        
        if(rules[0].searchLists !== ''){
            if(rules[0].searchLists === 'userdne'){
                lists.innerHTML = '<p>That user does not exist, please check your spelling and try again.</p>';
            } else if (rules[0].searchLists === 'userdnhl'){
                lists.innerHTML = '<p>That user does not have any lists yet.</p>';
            } else {
                var html = '';
                for(var i = 0; i < rules[0].searchLists.length; i++){
                    html += '<form method="GET" action="/purchase" id="purchase"><div class="listNameCont"><input type="hidden" name="listId" value="' + i + '"><h4>' + rules[0].searchLists[i].listName + '</h4><input type="submit" class="submit" value="View List"></input></div><ul>';
                    for(var j = 0; j < JSON.parse(rules[0].searchLists[i].listItems).length; j++) {
                        if(isUrl(JSON.parse(rules[0].searchLists[i].listItems)[j])){
                            html += '<li id="item"><a href="' + JSON.parse(rules[0].searchLists[i].listItems)[j] + '">Item ' + (j+1) + '</a> - ' + JSON.parse(rules[0].searchLists[i].itemPrices)[j] + '</li>';
                        } else {
                            html += '<li id="item">' + JSON.parse(rules[0].searchLists[i].listItems)[j] + ' - ' + JSON.parse(rules[0].searchLists[i].itemPrices)[j] + '</li>';
                        }
                    }
                    html += '</ul></form><hr>';
                }
                lists.innerHTML = html;
            }
        } else {
            lists.innerHTML = '<p>Search for your family members, friends, or anyones wishlists!</p>';
        }

        localStorage.setItem('userId', rules[0].userId);
    });
};