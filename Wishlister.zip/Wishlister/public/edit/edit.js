window.onload = (event) => {
    const deleteList = document.getElementById('deleteList');
    const editList = document.getElementById('editList');
    const addBtn = document.getElementById('add');
    const listName = document.getElementById('list_name');

    fetch('/api/rules')
        .then(response => response.json())
        .then(rules => {
            
            if(rules[0].userLists !== ''){
                const id = rules[0].editList; 
                listName.value = rules[0].userLists[id].listName;
                
                const listId = document.createElement('input');
                listId.type = 'hidden';
                listId.id = 'listId';
                listId.name = 'listId';
                listId.value = rules[0].userLists[id].listId;
                
                editList.appendChild(listId);
                
                const deleteListId = listId.cloneNode(true);
                deleteList.appendChild(deleteListId);

                for(var i = 0; i < JSON.parse(rules[0].userLists[id].listItems).length; i++) {
                    const item_container = document.createElement('div');
                    item_container.className = 'item-container';

                    const item = document.createElement('input');
                    item.type = 'text';
                    item.id = 'item';
                    item.name = 'item';
                    item.placeholder = 'Insert Item Here';
                    item.value = JSON.parse(rules[0].userLists[id].listItems)[i];
                    item.required = 'true';

                    const hiddenItem = document.createElement('input');
                    hiddenItem.type = 'hidden';
                    hiddenItem.id = 'purchased';
                    hiddenItem.name = 'purchased';
                    hiddenItem.value = JSON.parse(rules[0].userLists[id].purchased)[i];

                    const removeBtn = document.createElement('button');
                    removeBtn.id = 'remove';
                    removeBtn.innerHTML = 'X';

                    editList.appendChild(item_container);
                    item_container.appendChild(item);
                    item_container.appendChild(hiddenItem);
                    item_container.appendChild(removeBtn);

                    removeBtn.addEventListener('click', function () {
                        this.parentElement.remove();
                    });
                }

            }
    });

    addBtn.addEventListener('click', function () {
        
        const item_container = document.createElement('div');
        item_container.className = 'item-container';

        const item = document.createElement('input');
        item.type = 'text';
        item.id = 'item';
        item.name = 'item';
        item.placeholder = 'Insert Item Here';
        item.required = 'true';

        const hiddenItem = document.createElement('input');
        hiddenItem.type = 'hidden';
        hiddenItem.id = 'purchased';
        hiddenItem.name = 'purchased';
        hiddenItem.value = 'false';

        const removeBtn = document.createElement('button');
        removeBtn.id = 'remove';
        removeBtn.innerHTML = 'X';

        editList.appendChild(item_container);
        item_container.appendChild(item);
        item_container.appendChild(hiddenItem);
        item_container.appendChild(removeBtn);

        removeBtn.addEventListener('click', function () {
            this.parentElement.remove();
        });

    });
    
};