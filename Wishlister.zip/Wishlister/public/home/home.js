window.onload = (event) => {
    const faqGrid = document.getElementById("faqGrid");
    const seeMoreBtn = document.getElementById("seeMoreBtn");
    const createTab = document.getElementById('create');
    const createLink = document.getElementById('create2');
    const viewTab = document.getElementById('view');
    const viewLink = document.getElementById('view2');
    const regBtn = document.getElementById('register');
    const logBtn = document.getElementById('login');
    const profBtn = document.getElementById('profile');
    const logoBtn = document.getElementById('logout');

    fetch('/api/rules')
      .then(response => response.json())
      .then(rules => {
        localStorage.setItem('userId', rules[0].userId);
        if(!(rules[0].isLoggedIn) && localStorage.getItem('userId') === ''){
            createTab.style.display = 'none';
            createLink.style.display = 'none';
            viewTab.style.display = 'none';
            viewLink.style.display = 'none';
            regBtn.style.display = 'block';
            logBtn.style.display = 'block';
            profBtn.style.display = 'none';
            logoBtn.style.display = 'none';
        } else {
            createTab.style.display = 'block';
            createLink.style.display = 'block';
            viewTab.style.display = 'block';
            viewLink.style.display = 'block';
            regBtn.style.display = 'none';
            logBtn.style.display = 'none';
            profBtn.style.display = 'block';
            logoBtn.style.display = 'block';
        }
    });

    const faqItems = faqGrid.querySelectorAll(".faq-item");
    const initialItemCount = 4; // Show 4 FAQ items initially
    let expanded = false;

    // Hide FAQ items beyond initialItemCount
    faqItems.forEach((item, index) => {
        if (index >= initialItemCount) {
            item.style.display = "none";
        }
    });

    // Toggle visibility of additional FAQ items
    seeMoreBtn.addEventListener("click", function() {
        expanded = !expanded;
        faqItems.forEach((item, index) => {
            if (index >= initialItemCount) {
                item.style.display = expanded ? "block" : "none";
            }
        });

        // Change button text based on expanded state
        seeMoreBtn.textContent = expanded ? "See Less" : "See More";
    });
};