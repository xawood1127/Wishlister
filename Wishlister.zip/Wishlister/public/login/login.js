window.onload = async (event) => {
    var loginForm = document.getElementById("loginForm");
    var passwordInput = document.getElementById("password");
    var togglePassword = document.getElementById("togglePassword");
    var error = document.getElementById("loginAlert");
    var pass = document.getElementById("passAlert");
    error.style.display = 'none';
    pass.style.display = 'none';
  
    await fetch('/api/rules')
      .then(response => response.json())
      .then(rules => {
        if(rules[0].wrongInfo){
          error.style.display = 'block';
        } else {
          error.style.display = 'none';
        }
        
        if(rules[0].passChange){
          pass.style.display = 'block';
        } else {
          pass.style.display = 'none';
        }

        localStorage.setItem('userId', rules[0].userId);
    });

    // Form submission logic
    loginForm.addEventListener("submit", function(event) {
      var username = document.getElementById("username").value;
      var password = passwordInput.value;
    });
  
    //Ensuure password field is hidden
	  passwordInput.setAttribute('type', 'password');

    // Toggle password visibility logic
    togglePassword.addEventListener("click", function() {
      var type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
      passwordInput.setAttribute("type", type);
    });
};  