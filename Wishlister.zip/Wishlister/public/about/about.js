window.onload = (event) => {
    const createTab = document.getElementById('create');
    const createLink = document.getElementById('create2');
    const viewTab = document.getElementById('view');
    const viewLink = document.getElementById('view2');
    const regBtn = document.getElementById('register');
    const logBtn = document.getElementById('login');
    const profBtn = document.getElementById('profile');
    const logoBtn = document.getElementById('logout');

    fetch('/api/rules')
      .then(response => response.json())
      .then(rules => {
        if(!rules[0].isLoggedIn && localStorage.getItem('userId') === ''){
            createTab.style.display = 'none';
            createLink.style.display = 'none';
            viewTab.style.display = 'none';
            viewLink.style.display = 'none';
            regBtn.style.display = 'block';
            logBtn.style.display = 'block';
            profBtn.style.display = 'none';
            logoBtn.style.display = 'none';
        } else {
            createTab.style.display = 'block';
            createLink.style.display = 'block';
            viewTab.style.display = 'block';
            viewLink.style.display = 'block';
            regBtn.style.display = 'none';
            logBtn.style.display = 'none';
            profBtn.style.display = 'block';
            logoBtn.style.display = 'block';
        }

        localStorage.setItem('userId', rules[0].userId);
    });
};