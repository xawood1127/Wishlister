window.onload=function(){
    const addBtn = document.getElementById('add');
    const list = document.getElementById('createList');


    addBtn.addEventListener('click', function () {
        
        const item_container = document.createElement('div');
        item_container.className = 'item-container';

        const item = document.createElement('input');
        item.type = 'text';
        item.id = 'item';
        item.name = 'item';
        item.placeholder = 'Insert Item Here';
        item.required = 'true';

        const itemPrice = document.createElement('input');
        itemPrice.type = 'text';
        itemPrice.id = 'itemPrice';
        itemPrice.name = 'itemPrice';
        itemPrice.placeholder = 'Price';
        itemPrice.required = 'true';

        const hiddenItem = document.createElement('input');
        hiddenItem.type = 'hidden';
        hiddenItem.id = 'purchased';
        hiddenItem.name = 'purchased';
        hiddenItem.value = 'false';

        const removeBtn = document.createElement('button');
        removeBtn.id = 'remove';
        removeBtn.innerHTML = 'X';

        list.appendChild(item_container);
        item_container.appendChild(item);
        item_container.appendChild(itemPrice);
        item_container.appendChild(hiddenItem);
        item_container.appendChild(removeBtn);

        removeBtn.addEventListener('click', function () {
            this.parentElement.remove();
        });

    });

}